n1 = op('chopto1')
d = n1[0,0]

def onSetupParameters(scriptOp):
    return
def onPulse(par):
    return
def onCook(scriptOp):
    print(d)
    return
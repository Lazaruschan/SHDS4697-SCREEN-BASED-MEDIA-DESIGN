import processing.video.*;
import oscP5.*;
import netP5.*;

Capture video;
int gridWidth = 10;
int gridHeight = 10;
int cellWidth;
int cellHeight;

int averagebrightnessValue [];

OscP5 oscP5;
NetAddress dest;

void setup() {
  size(640, 480);
  String[] cameras = Capture.list();

  if (cameras.length == 0) {
    println("There are no cameras available for capture.");
    exit();
  } else {
    println("Available cameras:");
    for (int i = 0; i < cameras.length; i++) {
      println(cameras[i]);
    }

    // Use the default camera
    //Students who receive error messages when opening the built-in webcam, disable the code below. (Ctrl + /)
    video = new Capture(this, cameras[0]);
    
    //Students who receive error messages when opening the built-in webcam, activate the code below. (Ctrl + /)
    //video = new Capture(this, width, height, "pipeline:autovideosrc", 30);
    
    video.start();
  }

  cellWidth = width / gridWidth;
  cellHeight = height / gridHeight;

  oscP5 = new OscP5(this, 9000);
  dest = new NetAddress("127.0.0.1", 6448);

  averagebrightnessValue = new int[gridWidth*gridHeight];
}

void draw() {
  if (video.available()) {
    video.read();
  }
  video.loadPixels();
  if (frameCount % 2 == 0) {
    OscMessage myMessage = new OscMessage("/wek/inputs");
    for (int i = 0; i < gridWidth; i++) {
      for (int j = 0; j < gridHeight; j++) {
        // Calculate the starting index for the pixels in this grid cell
        int x = i * cellWidth;
        int y = j * cellHeight;
        int brightnessValue = 0;
        int count = 0;

        // Average the colors of the pixels in the current grid cell
        for (int xi = x; xi < x + cellWidth; xi++) {
          for (int yi = y; yi < y + cellHeight; yi++) {
            int index = xi + yi * video.width;
            color c = video.pixels[index];
            brightnessValue += red(c);
            count++;
          }
        }

        // Calculate the average color
        averagebrightnessValue[i*j] = brightnessValue / count;

        // Draw the rectangle
        fill(averagebrightnessValue[i*j]);
        myMessage.add((float)averagebrightnessValue[i*j]);
        
        rect(x, y, cellWidth, cellHeight);
      }
    }
    oscP5.send(myMessage, dest);
  }

  //printArray(averagebrightnessValue);
}

void captureEvent(Capture video) {
  video.read();
}
